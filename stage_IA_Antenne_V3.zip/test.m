function test(A)
    disp(A);
end