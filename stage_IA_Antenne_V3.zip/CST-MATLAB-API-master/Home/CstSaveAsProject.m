function CstSaveAsProject(mws,ProjectName)

mws.invoke('saveas',ProjectName,'false');
end